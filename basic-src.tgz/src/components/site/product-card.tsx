"use client";

import { useCallback, useRef, useState } from "react";
import Image from "next/image";
import { Button, Stepper } from "@/components/ui";
import { cx } from "@/components/ui/cx";
import { WavePattern } from "./wave-pattern";
import { photoFor } from "@/lib/catalog/photos";
import { WHOLE_MULTIPLIER, type Product } from "@/lib/catalog/products";
import { fill, formatPrice } from "@/lib/i18n/format";
import type { Messages } from "@/lib/i18n/dictionaries";
import type { Locale } from "@/lib/i18n/config";

/**
 * One product card, for every screen size.
 *
 * The reference shipped two — `DessertCard` (`hidden md:block`) and
 * `MobileDessertCard` (`md:hidden`), 504 lines between them, both mounted, both in
 * the bundle, and already disagreeing about radius, surface, stepper height,
 * `aria-pressed` and spring constants. This is one component; the hover
 * affordances live behind `@media (hover: hover)` and the tap-to-open behaviour is
 * the baseline underneath them.
 *
 * The motion is the reference's, curve for curve — see the spring block in
 * globals.css. What changed is where it runs: CSS, off the main thread, with the
 * pointer feeding two custom properties instead of eight spring integrators.
 */

type Props = {
  product: Product;
  index: number;
  locale: Locale;
  t: Messages;
  priority: boolean;
};

export function ProductCard({ product, index, locale, t, priority }: Props) {
  const ref = useRef<HTMLElement>(null);
  const [open, setOpen] = useState(false);
  const [qty, setQty] = useState(0);
  const [whole, setWhole] = useState(false);

  const hasWhole = product.whole;
  const variant: "piece" | "whole" = hasWhole && whole ? "whole" : "piece";
  const photo = photoFor(product.slug);

  const priceLabel = formatPrice(
    locale,
    variant === "whole" ? product.price * WHOLE_MULTIPLIER : product.price,
  );

  const onPointerMove = useCallback((event: React.PointerEvent<HTMLElement>) => {
    const el = ref.current;
    if (!el || event.pointerType !== "mouse") return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--px", String((event.clientX - r.left) / r.width - 0.5));
    el.style.setProperty("--py", String((event.clientY - r.top) / r.height - 0.5));
  }, []);

  const onPointerLeave = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--px", "0");
    el.style.setProperty("--py", "0");
  }, []);

  return (
    <article
      ref={ref}
      data-card
      data-open={open || undefined}
      style={{ "--i": index } as React.CSSProperties}
      onPointerMove={onPointerMove}
      onPointerLeave={onPointerLeave}
      className="group/card card-drift card-enter perspective-card relative"
    >
      <div className="card-lift border-line bg-surface-sunken rounded-card relative overflow-hidden border shadow-soft">
        <div className="card-tilt relative">
          {/*
            The ribbons sit under the WHOLE card — photo and controls both — which
            is what makes the card warm through as it opens, rather than showing a
            halo around the picture only. `bg-surface-page` over the card's own
            surface, exactly as the reference layered cream over cream-deep.
          */}
          <div aria-hidden="true" className="card-waves text-brand absolute inset-0 z-0">
            <div className="bg-surface-page absolute inset-0" />
            <WavePattern />
          </div>

          <div className="relative z-10">
            {/*
              The photo is the disclosure control — a real <button> with
              aria-expanded. The reference used a <div> with onClick, no role and no
              tabIndex, so on a touchscreen the description was unreachable by
              keyboard entirely.
            */}
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls={`d-${product.slug}`}
              className="block w-full text-left"
            >
              {/* The frame carries the page ground: the margin baked into each photo
                  is the same cream, so at rest the two are indistinguishable and the
                  ribbons appear only once the frame contracts away from the card. */}
              <div className="card-frame bg-surface-page aspect-portrait relative w-full overflow-hidden">
                <Image
                  src={photo.src}
                  alt={product.name[locale]}
                  fill
                  sizes="(min-width: 1280px) 20vw, (min-width: 1024px) 30vw, (min-width: 640px) 45vw, 90vw"
                  priority={priority}
                  {...(priority ? {} : { loading: "lazy" as const })}
                  {...(photo.blurDataURL
                    ? { placeholder: "blur" as const, blurDataURL: photo.blurDataURL }
                    : {})}
                  className="card-photo object-cover"
                />

                {/* A contrast floor, not a gradient that hopes the photo is dark —
                    most of this catalogue is a pale dessert on a pale surface. */}
                <div aria-hidden="true" className="scrim absolute inset-x-0 bottom-0 h-1/2" />

                <div className="absolute inset-x-0 bottom-0 p-5">
                  <div className="flex items-end justify-between gap-4">
                    <h3 className="font-display text-title text-content-on-photo font-bold text-balance">
                      {product.name[locale]}
                    </h3>
                    <span className="font-display text-content-on-photo shrink-0 overflow-hidden font-bold">
                      {/* Keyed so a change restarts the slide, the way
                          AnimatePresence did in the reference. */}
                      <span key={variant} className="value-slide block text-body-sm">
                        {priceLabel}
                      </span>
                    </span>
                  </div>

                  <div id={`d-${product.slug}`} className="card-reveal">
                    <div>
                      <p className="text-body-sm text-content-on-photo/90 pt-2">
                        {product.note[locale]}
                      </p>
                      {/* How it keeps — the line a venue actually buys on. */}
                      <p className="text-micro text-content-on-photo/70 pt-2 uppercase">
                        {product.formats
                          .filter((f) => f !== "whole")
                          .map((f) => t.formats[f])
                          .join(" · ")}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </button>

            {hasWhole && (
              <div className="absolute top-4 right-4 z-20">
                <VariantToggle
                  whole={whole}
                  onChange={setWhole}
                  labels={[t.catalog.piece, t.catalog.wholeCake]}
                />
              </div>
            )}

            {qty > 0 && (
              <span
                key={qty}
                className={cx(
                  "badge-pop font-display bg-brand text-content-on-brand absolute right-4 z-20",
                  "grid size-9 place-items-center rounded-pill text-body-sm font-bold tabular-nums",
                  hasWhole ? "top-16" : "top-4",
                )}
              >
                {qty}
              </span>
            )}
          </div>

          <div className="relative z-10 grid grid-cols-control-fill items-center gap-3 p-5">
            <Stepper
              value={qty}
              onDecrement={() => setQty((q) => Math.max(0, q - 1))}
              onIncrement={() => setQty((q) => q + 1)}
              decrementLabel={t.catalog.removeOne}
              incrementLabel={t.catalog.addOne}
              valueLabel={fill(t.order.lineQuantity, { name: product.name[locale] })}
            />

            <Button variant="solidWipe" onClick={() => setQty((q) => q + 1)} fullWidth>
              {variant === "whole" ? t.catalog.addWhole : t.catalog.add}
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}


/**
 * A radio group, not two toggle buttons.
 *
 * The reference used a pair of `aria-pressed` buttons, which announces two
 * independent switches rather than one choice of two. The sliding indicator
 * replaces Framer's shared-element `layoutId` with a translated element on the
 * same spring.
 */
function VariantToggle({
  whole,
  onChange,
  labels,
}: {
  whole: boolean;
  onChange: (whole: boolean) => void;
  labels: [string, string];
}) {
  return (
    <div
      role="radiogroup"
      /*
       * A grid, not a flex row of `w-1/2` children. Halving a flex child whose
       * label is `nowrap` is circular — the browser resolves it by letting the
       * label spill, which is why "Cela torta" and "Целый торт" hung off the right
       * edge of the card at 320 and 390px. Equal grid columns size to the widest
       * label and the track sizes to them.
       */
      className={cx(
        "border-line bg-surface-raised/90 relative grid max-w-full grid-cols-2 rounded-pill border p-1",
        "shadow-soft backdrop-blur-md",
      )}
    >
      <span
        aria-hidden="true"
        style={{ "--seg": whole ? 1 : 0 } as React.CSSProperties}
        className="pill-indicator bg-brand absolute inset-y-1 left-1 rounded-pill"
      />
      {labels.map((label, i) => {
        const active = (i === 1) === whole;
        return (
          <button
            key={label}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(i === 1)}
            className={cx(
              "relative z-10 rounded-pill px-3 py-1.5 text-caption font-semibold whitespace-nowrap transition-ink",
              active ? "text-content-on-brand" : "text-content-secondary hover:text-brand",
            )}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
