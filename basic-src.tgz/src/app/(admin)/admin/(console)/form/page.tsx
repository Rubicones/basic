import { Button, Card, IconChevronDown } from "@/components/ui";
import { listFields } from "@/lib/admin/queries";
import { FieldEditor } from "./editor";
import { deleteField, moveField } from "./actions";

export default async function FormPage() {
  const fields = await listFields();

  return (
    <>
      <div className="mb-2">
        <h1 className="text-display-md">Order form</h1>
      </div>
      <p className="text-body-sm text-content-secondary mb-8 max-w-measure">
        These are the questions the order form asks. A field that is hidden keeps its answers in
        past orders — nothing here rewrites an order that has already been placed.
      </p>

      <div className="flex flex-col gap-4">
        {fields.map((field, index) => (
          <div key={field.id} className="flex items-start gap-2">
            <div className="min-w-0 flex-1">
              <FieldEditor field={field} />
            </div>

            <div className="flex shrink-0 flex-col gap-1 pt-2">
              <form action={moveField}>
                <input type="hidden" name="id" value={field.id} />
                <input type="hidden" name="direction" value="up" />
                <Button type="submit" variant="ghost" size="sm" disabled={index === 0}>
                  <span className="rotate-180 flex">
                    <IconChevronDown size={16} />
                  </span>
                </Button>
              </form>
              <form action={moveField}>
                <input type="hidden" name="id" value={field.id} />
                <input type="hidden" name="direction" value="down" />
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  disabled={index === fields.length - 1}
                >
                  <IconChevronDown size={16} />
                </Button>
              </form>
              <form action={deleteField}>
                <input type="hidden" name="id" value={field.id} />
                <Button type="submit" variant="ghost" size="sm">
                  ✕
                </Button>
              </form>
            </div>
          </div>
        ))}

        <Card padding="none">
          <div className="p-4">
            <p className="text-body-sm text-content-secondary mb-4">Add a question</p>
          </div>
          <div className="border-line border-t">
            <FieldEditor field={null} defaultOpen />
          </div>
        </Card>
      </div>
    </>
  );
}
