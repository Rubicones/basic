import Link from "next/link";
import { Card, Grid } from "@/components/ui";
import { createClient } from "@/lib/supabase/server";

export default async function ConsoleHome() {
  const supabase = await createClient();

  // Counts only — `head: true` asks for the number without shipping the rows.
  const [products, fields, orders] = await Promise.all([
    supabase.from("products").select("*", { count: "exact", head: true }),
    supabase.from("order_fields").select("*", { count: "exact", head: true }),
    supabase.from("orders").select("*", { count: "exact", head: true }).eq("status", "new"),
  ]);

  const cards = [
    { href: "/admin/products", label: "Products", value: products.count ?? 0 },
    { href: "/admin/form", label: "Order form fields", value: fields.count ?? 0 },
    { href: "/admin/orders", label: "New orders", value: orders.count ?? 0 },
  ];

  return (
    <>
      <h1 className="text-display-md">Overview</h1>

      <div className="mt-8">
        <Grid cols={3} gap={5}>
          {cards.map((card) => (
            <Link key={card.href} href={card.href}>
              <Card interactive>
                <p className="text-micro text-content-secondary uppercase">{card.label}</p>
                <p className="font-display text-display-md mt-2 font-extrabold tabular-nums">
                  {card.value}
                </p>
              </Card>
            </Link>
          ))}
        </Grid>
      </div>
    </>
  );
}
