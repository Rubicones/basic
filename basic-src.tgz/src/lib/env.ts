/**
 * Typed environment access.
 *
 * Reads happen here and nowhere else, so a missing variable fails with its own
 * name rather than surfacing later as `undefined` inside a URL.
 *
 * Getters, not eager constants: a module that needs only `siteUrl` should not
 * fail because Supabase has not been configured yet. The check still runs on
 * every read, so nothing gets to be quietly undefined.
 *
 * `process.env.X` is written out literally — Next substitutes these at build time
 * by static analysis, so `process.env[name]` would silently yield undefined in
 * the browser bundle.
 */

function required(value: string | undefined, name: string): string {
  if (!value) {
    throw new Error(
      `Missing environment variable ${name}. Copy .env.example to .env.local and fill it in.`,
    );
  }
  return value;
}

/** Safe on the client — every value here is NEXT_PUBLIC_. */
export const env = {
  /** Absolute origin, no trailing slash. Canonicals, hreflang and the sitemap. */
  get siteUrl(): string {
    return required(process.env.NEXT_PUBLIC_SITE_URL, "NEXT_PUBLIC_SITE_URL").replace(/\/$/, "");
  },
  get supabaseUrl(): string {
    return required(process.env.NEXT_PUBLIC_SUPABASE_URL, "NEXT_PUBLIC_SUPABASE_URL");
  },
  get supabaseAnonKey(): string {
    return required(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, "NEXT_PUBLIC_SUPABASE_ANON_KEY");
  },
} as const;
