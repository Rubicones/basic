import "server-only";
import { createClient } from "@/lib/supabase/server";
import { env } from "@/lib/env";
import type {
  OrderDetail,
  OrderFieldWithTranslations,
  OrderRow,
  ProductWithTranslations,
} from "./types";

/**
 * Every read here runs on the anon key with the administrator's own session, so
 * RLS is what grants it — not a service-role key that would make the policies
 * decorative.
 */

export const PHOTO_BUCKET = "product-photos";

/** Public URL for a stored photo. Storage paths are relative; the site needs absolute. */
export function photoUrl(path: string | null): string | null {
  if (!path) return null;
  return `${env.supabaseUrl}/storage/v1/object/public/${PHOTO_BUCKET}/${path}`;
}

export async function listProducts(): Promise<ProductWithTranslations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, product_translations(locale, name, note)")
    .order("position");

  if (error) throw new Error(error.message);
  return (data ?? []) as ProductWithTranslations[];
}

export async function getProduct(slug: string): Promise<ProductWithTranslations | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, product_translations(locale, name, note)")
    .eq("slug", slug)
    .maybeSingle();

  if (error) throw new Error(error.message);
  return (data as ProductWithTranslations | null) ?? null;
}

export async function listFields(): Promise<OrderFieldWithTranslations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("order_fields")
    .select("*, order_field_translations(locale, label, placeholder, help)")
    .order("position");

  if (error) throw new Error(error.message);
  return (data ?? []) as OrderFieldWithTranslations[];
}

export async function listOrders(): Promise<OrderRow[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as OrderRow[];
}

export async function getOrder(id: string): Promise<OrderDetail | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("orders")
    .select(
      "*, order_items(id, variant, qty, unit_price_rsd, name_snapshot)," +
        " order_answers(field_key, label_snapshot, value, position)",
    )
    .eq("id", id)
    .maybeSingle();

  if (error) throw new Error(error.message);
  return (data as OrderDetail | null) ?? null;
}
