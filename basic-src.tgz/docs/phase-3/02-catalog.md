# Screen 2 — catalog

Reviewed before rebuilding: `Catalog.tsx` (120 lines), `MobileCatalog.tsx` (384),
`DessertCard.tsx` (250) and `WavePattern.tsx` in the reference.

## Markup faults found

### The screen exists twice

`Catalog` is `hidden md:block`; `MobileCatalog` is `md:hidden`. Both are mounted at every
width, both ship, both run scroll listeners and motion. They had already drifted:

| | desktop | mobile |
|---|---|---|
| card radius | 2rem | 1.75rem |
| card surface | `bg-cream-deep` | `bg-card` |
| stepper | `h-11`, `size-8` buttons | `h-12`, `size-9` |
| filter pills | no `aria-pressed` | `aria-pressed` ✓ |
| filter pills | no check icon | animated check |
| haptics | — | `navigator.vibrate(8)` |
| column switcher | 3 / 4 / 5 | absent |
| detail reveal | over the photo | accordion below it |
| entrance spring | 120 / 16 | 240 / 26 / 0.75 |

504 lines for one screen, and nine details on which the two disagreed.

### The card

1. **The disclosure control is a `<div>` with `onClick`.** No `role`, no `tabIndex`, no key
   handler — and it carries `cursor-default`, so it announces itself as non-interactive
   while being the only way to read the description. On a touchscreen that description is
   unreachable by keyboard entirely.
2. **Layout properties are animated.** The description reveal animates `height: 0 → auto`;
   the mobile card animates its photo's `height` 260px ↔ 200px. Both lay out the card on
   every frame.
3. **Two animations fight over one node.** The outer `<article>` carries Framer's `layout`
   *and* a scroll-driven `y` transform. They write the same property, so the card jitters
   whenever the grid reflows — which is every time the filter changes.
4. **The variant toggle is two `aria-pressed` buttons**, which announces two independent
   switches rather than one choice of two.
5. **`width={1024} height={1024}` on an image rendered into `aspect-4/5`** — the declared
   ratio contradicts the rendered one. The mobile card's image declares no dimensions at all.
6. **Every image is `loading="lazy"`, including the first.**
7. **The scrim is `from-ink/75 via-ink/10`** over an arbitrary photograph. Most of this
   catalogue is a pale dessert on a pale surface, so the product name lands below threshold.
8. **No empty state.** A filter that matches nothing renders an empty grid in silence.
9. **Alpha-on-palette everywhere**: `border-ink/12`, `bg-card/35`, `bg-accent/55`,
   `text-cream/85` — six alphas of one accent color across the two files.

### The category model

`products.category_slug` is a single column, so a product sits in exactly one group. The
real catalogue does not work that way: the New York cheesecake is a whole cake, a frozen
item *and* a display-case item. The reference's model cannot express its own catalogue.

## What the rebuild does

One `Catalog`, one `ProductCard`, responsive. Hover affordances sit behind
`@media (hover: hover)`; the tap-to-open behaviour is the baseline underneath them.

- The disclosure is a real `<button>` with `aria-expanded` and `aria-controls`.
- The variant toggle is a `radiogroup` with two radios.
- The reveal is `grid-template-rows: 0fr → 1fr` — height-to-auto on the compositor.
- Drift, lift and tilt live on three separate elements, so no two animations share a property.
- The scrim has a floor: heavy under the caption band, out of the way above it.
- Empty state, and a `sizes` attribute on every image.
- Filtering is by **storage format**, and a product can be in several groups — which is
  both what the deck describes and the question a venue actually asks. Provisional until
  the schema decision lands.

### The animations are the reference's, exactly

This was the requirement, so it was done by arithmetic rather than by eye. Framer's springs
are physics, not bezier curves; each one below is the analytic solution of its damped
harmonic oscillator, sampled and emitted as a CSS `linear()` — overshoot included, which is
the part a `cubic-bezier` cannot express and the part you see.

| motion | reference spring | settle | where |
|---|---|---|---|
| card entrance | 120 / 16 / 1 | 721ms | `--ease-spring-enter` |
| hover lift −6px | 220 / 20 / 1 | 693ms | `--ease-spring-lift` |
| pointer tilt ±7° / ±6°, photo parallax ±14px | 140 / 18 / 0.4 | 489ms | `--ease-spring-tilt` |
| photo frame 1 → 0.915, radius 32 → 28 | 180 / 20 / 1 | 602ms | `--ease-spring-zoom` |
| quantity badge 0.4 → 1 | 400 / 14 / 1 | 916ms | `--ease-spring-pop` |
| value change, slide from +14px | 420 / 30 / 1 | 395ms | `--ease-spring-slide` |
| variant indicator | 480 / 34 / 0.6 | 330ms | `--ease-spring-pill` |

The rest carried over as written: photo 1.02 → 1.14 over 700ms on the house curve, wave
layer 0.46 → 1, the ribbons' 8-second drift while open, the ink wipe under the add button,
the `index % 3` entrance stagger, and the scroll drift of +26 → −26px.

What changed is where it runs. The pointer sets two custom properties, `--px` and `--py`,
and every derived transform is CSS — one write per frame instead of eight spring
integrators. The scroll drift and the filter rail's settle are scroll-driven animations, so
they cost no JavaScript at all and simply hold still where `view()` timelines are absent.
The entrance is an `IntersectionObserver` in eleven lines, matching `whileInView once`;
cards are visible without it, so nothing waits on JavaScript to paint.

## Verified

- **Hover, measured from computed styles**: tilt `matrix3d` with the expected rotation for
  the pointer position, frame `scale(0.915)`, radius 32px → 28px, reveal `0px → 29.7px`,
  waves `0.46 → 1`, lift `translateY(-6px)`. All seven fire.
- **`prefers-reduced-motion: reduce`**: tilt, lift and frame all resolve to `none`. The
  global rule collapses durations but a transform still lands instantly, so these are held
  at rest explicitly.
- **No horizontal scroll** at 320, 390 or 1440, and no element escapes its card. The variant
  toggle did overflow on the first pass — halving a flex child whose label is `nowrap` is
  circular, and the browser resolves it by letting the label spill, which put "Cela torta"
  and "Целый торт" outside the card. It is a two-column grid now.
- **Filtering**: "Bez vitrine" returns 5 of 19.
- Checked in all three locales.

## Data, after the price list

The roster now comes from the summer 2026 price list, not the deck — the deck's
slides and the sheet disagreed, and the sheet is the complete one. 15 products;
the three whole-cake rows fold into medovik, napoleon and the two cheesecakes as a
variant rather than separate items.

- **Price** is the recommended venue retail column, as one figure: the sheet quotes
  ranges and a card shows one number, so each is the middle of its range rounded to
  the nearest 10. Syrniki had no venue price and carries a stand-in, flagged in the
  fixture as `priceIsPlaceholder`.
- **Whole cake** is the piece price × 6. The sheet does carry two real whole-cake
  figures — medovik 5.600 and napoleon 7.800 — and both are well above ×6, so those
  two are currently under-priced.
- **Storage formats** are read from the sheet's own storage and shelf-life columns
  rather than guessed, which also replaced the deck-derived grouping. "Extras" is
  gone: the caramels are not on the price list.
- **Descriptions** are one sentence each, written as placeholder copy in all three
  languages until the kitchen writes its own.
- Photographs are reassigned to the new roster. Six products carry another
  product's picture, flagged as `photoIsPlaceholder`: berry tart, bird's milk,
  choux rings, mravinjak, carrot cake and syrniki.

## Card revisions after review

- **No mat.** An earlier pass baked a cream margin into each photo to give the
  desserts air. It read as weak, so the photo bleeds to the card edge as in the
  reference; the photographs are close-ups and that is a photography problem, not a
  layout one.
- **The variant indicator was 8px too far.** It is `50% - 4px` wide starting 4px in,
  so its far position is 50% of the track — exactly its own width. One step is
  therefore 100% of itself and nothing more; the extra `+ 8px` pushed it past the
  right inset on "Whole cake".
- **A stale image cache, not a crop.** "Still cropped" turned out to be
  `.next/cache/images` serving the previous export under unchanged URLs. Re-exported
  images need `.next` cleared before they appear.

## Open


- **Prices.** Every card renders its "on request" state. The catalogue needs real ones.
- **Descriptions.** The reference revealed a tasting note; there is no source for one, so
  the reveal carries the storage formats instead.
- **Five products still need photography** — Medovik sa malinom, Kolutići, Sirniki, Vanila
  sufle and Kokos karamela currently borrow another product's picture. The fixture flags
  each with `photoIsPlaceholder`.
- The category model above is provisional until the schema decision.
